#pragma once
#define NAME char[50]
#define KEY int